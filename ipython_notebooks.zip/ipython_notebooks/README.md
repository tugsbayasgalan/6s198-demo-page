This folder contains all of our code for data processing and deep learning models. To try running our data processing code, download datasets from these links (https://www.kaggle.com/gyani95/380000-lyrics-from-metrolyrics/data, https://www.kaggle.com/mousehead/songlyrics) and put them in Data Processing folder. 

Specifically:

bigram_train.ipynb - Bigram model with a single LSTM layer
char_single_layer.ipynb - Character generation model with a single LSTM layer 
bigram_aws.py - Bigram model we ran on AWS
char_aws.py - Character model we ran on AWS
